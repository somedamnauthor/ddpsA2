rm output/*
rm input/*.ext
cp input/data/$2 input/file.ext

python2 $1 4 4 mapreduce final 0